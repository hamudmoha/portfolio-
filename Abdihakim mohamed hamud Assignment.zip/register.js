
    function showSignUp() {
      document.getElementById("signupForm").style.display = "block";
      document.getElementById("signInForm").style.display = "none";
    }

    function showSignIn() {
      document.getElementById("signupForm").style.display = "none";
      document.getElementById("signInForm").style.display = "block";
    }
  